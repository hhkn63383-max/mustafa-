import I18nManager from "../core/i18n.js";


export const i18n = new I18nManager()
